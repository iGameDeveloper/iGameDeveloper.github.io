﻿{
	"version": 1481114217,
	"fileList": [
		"data.js",
		"c2runtime.js",
		"jquery-2.1.1.min.js",
		"offlineClient.js",
		"images/player-sheet0.png",
		"images/tiledbackground.png",
		"images/tiledbackground2.png",
		"images/background-sheet0.png",
		"images/wall-sheet0.png",
		"images/sprite-sheet0.png",
		"images/cam-sheet0.png",
		"icon-16.png",
		"icon-32.png",
		"icon-114.png",
		"icon-128.png",
		"icon-256.png",
		"loading-logo.png"
	]
}